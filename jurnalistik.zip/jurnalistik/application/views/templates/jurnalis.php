<!-- isinya -->
<div class="row main mt-3">
	<div class="col-md-6">
		<h1 class="display-3">
			<span>Forum Jurnalistik Di Indonesia</span>
		</h1>
		<!-- gunanya display untuk mengatur besar kecil tulisan -->
		<!-- paragraph -->
		<p>
			Ayo asah kemampuanmu dengan menulis cerpen dan membaca buku
			<i class="fas fa-pencil-alt"></i>
		</p>
		<!-- tutup paragraph -->
		<a class="enjoy-now btn btn-primary wow fadeInLeft text-uppercase" href="" data-toggle="modal" data-target="#signUp">Detail</a>
		<!-- btn lg memperbesar tombol -->
		<a href="<?= base_url('jurnal/Login'); ?>" class="btn btn-danger tombol ml-4">Sig In</a>
	</div>
</div>
<!--  -->

<img src="<?= base_url("assets/") ?>img/gadjet.png" class="bg-img" />
</div>
<!--  -->
<!-- service -->
<h3 class="mt-5 text-center hoho bold ">Out Service</h3>

<div class="container">
	<div class="row text-center mt-5 hoho">
		<div class="col-md-4">
			<i class="fas fa-laptop-code h1"></i>
			<h3>Laptop Coder</h3>
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim hic
			esse ducimus sit voluptas. Repudiandae magni maiores modi iusto
			earum? Provident magni, voluptate repellat voluptas rerum molestias
			voluptates laudantium hic.
		</div>
		<div class="col-md-4">
			<i class="fas fa-crop-alt h1"></i>
			<h3>Graphic Desaigner</h3>
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi
			veritatis quia blanditiis voluptates, aliquid magni consectetur.
			Pariatur eos sapiente officiis harum distinctio, accusamus quibusdam
			error mollitia dolore porro voluptates cum?
		</div>
		<div class="col-md-4">
			<i class="fas fa-camera-retro h1"></i>
			<h3>Social Markerter</h3>
			Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veritatis,
			soluta! Adipisci vero fugit magni quod totam. Eveniet, minima
			consectetur voluptas explicabo quo ad earum ullam ipsum quibusdam
			quod minus dolorem!
		</div>
	</div>
	<div class="row text-center mt-5 hoho">
		<div class="col-md-4">
			<i class="fas fa-laptop-code h1"></i>
			<h3>Laptop Coder</h3>
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim hic
			esse ducimus sit voluptas. Repudiandae magni maiores modi iusto
			earum? Provident magni, voluptate repellat voluptas rerum molestias
			voluptates laudantium hic.
		</div>
		<div class="col-md-4">
			<i class="fas fa-crop-alt h1"></i>
			<h3>Graphic Desaigner</h3>
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi
			veritatis quia blanditiis voluptates, aliquid magni consectetur.
			Pariatur eos sapiente officiis harum distinctio, accusamus quibusdam
			error mollitia dolore porro voluptates cum?
		</div>
		<div class="col-md-4">
			<i class="fas fa-camera-retro h1"></i>
			<h3>Social Markerter</h3>
			Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veritatis,
			soluta! Adipisci vero fugit magni quod totam. Eveniet, minima
			consectetur voluptas explicabo quo ad earum ullam ipsum quibusdam
			quod minus dolorem!
		</div>
	</div>
</div>
<!--  -->
<!-- footer -->

<div class="container mt-3">
	<div class="row text-white p-4 text-justify mt-5 workingspace">
		<div class="col-md-4">
			<img src="<?= base_url("assets/") ?>img/gadjet.png" alt="Working Space" class="img-fluid" />
		</div>
		<div class="col-md-4">
			<h2><span>Bacalah Bukumu Dari Sekarang</span></span></h2>
			<p>
				Buku Adalah Teman Yang Asyik Di Saat Kamu Sendirian
			</p>
			<a href="#" class="btn btn-danger tombol">Gallery Buku</a>
		</div>
		<div class="col-md-4 mt-5">
			<strong>
				LANGGANAN BACA BUKU FAVORIT
			</strong>
			<input type="text" name="" class="form-control rounded-pill mt-3" placeholder="Masukkan Email Anda" />
			<input type="submit" class="btn btn-primary tombol mt-2 mr-3" />
			<button class="btn-btn-outline-primary rounded-circle mr-3 mt-3">
				<i class="fab fa-instagram"></i>
			</button>
			<button class="btn-btn-outline-primary rounded-circle mr-3 mt-2">
				<i class="fab fa-facebook-square"></i>
			</button>
			<button class="btn-btn-outline-primary rounded-circle mr-3 mt-2">
				<i class="fab fa-twitter-square"></i>
			</button>
		</div>

	</div>
</div>
<!-- Testimonial -->
<section class="testimonial">
	<div class="row justify-content-center">
		<div class="col-lg-8">
			<p class="text-white">"Jika Kamu Pengen Menghancurkan Sebuah Peradaban Maka Hancurkanlah Buku Bukunya"</p>
		</div>
	</div>
	<div class="row justify-content-center">
		<div class="col-lg-6 justify-content-center d-flex">
			<img src="<?= base_url("assets/") ?>img/naruto.jpg" alt="Testimonial 1">
			<img src="<?= base_url("assets/") ?>img/naruto.jpg" alt="Testimonial 2" class="img-main">
			<img src="<?= base_url("assets/") ?>img/naruto.jpg" alt="Testimonial 3">
		</div>
	</div>
	<div class="row justify-content-center info-text">
		<div class="col-lg text-center">
			<h5>Developer</h5>
			<p class="text-white">Mustofa</p>

		</div>
	</div>
</section>
<!-- akhir Testimonial -->
</div>
