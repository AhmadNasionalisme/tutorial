  <div class="gallery mb-5">


  	<div class="container mt-5">
  		<div class="row mt-3 ">
  			<div class="col-md-4 ">
  				<div class="card satu mb-3">
  					<div class="card-head">
  						<img src="<?= base_url('assets/') ?>img/logo.png" alt="logo" class="card-logo">
  						<img src="<?= base_url('assets/') ?>img/gadjet.png" alt="Shoe" class="product-img mr-4" width="200px">

  						<span class="back-text">

  						</span>
  					</div>
  					<div class="card-body">
  						<table class="table table-borderless">
  							<!-- table table-borderless kegunaannya biar tabel gak memiliki border -->
  							<tr>
  								<th> Nama Buku </th>
  								<td><span class="badge badge-success">Anak Anak Reveolusi</span></td>
  							</tr>
  							<tr>
  								<th> Terbitan </th>
  								<td><span class="badge badge-success">2001</span></td>
  							</tr>
  							<tr>
  								<th> Pengarang </th>
  								<td><span class="badge badge-success">Achmad</span></td>
  							</tr>
  							<tr>
  								<th> Penerbit </th>
  								<td><span class="badge badge-success">Anak Anak Reveolusi</span></td>
  							</tr>

  						</table>
  						<div class=" product-properties">

  							<span class="product-color">

  								<ul class="ul-color">
  									<li><a href="#" class="orange active"></a></li>
  									<li><a href="#" class="green"></a></li>
  									<li><a href="#" class="yellow"></a></li>
  								</ul>
  							</span>

  						</div>
  					</div>
  				</div>
  			</div>
  			<div class="col-md-4 ">
  				<div class="card satu mb-3">
  					<div class="card-head">
  						<img src="<?= base_url('assets/') ?>img/logo.png" alt="logo" class="card-logo">
  						<img src="<?= base_url('assets/') ?>img/gadjet.png" alt="Shoe" class="product-img mr-4" width="200px">

  						<span class="back-text">

  						</span>
  					</div>
  					<div class="card-body">
  						<table class="table table-borderless">
  							<!-- table table-borderless kegunaannya biar tabel gak memiliki border -->
  							<tr>
  								<th> Nama Buku </th>
  								<td><span class="badge badge-success">Anak Anak Reveolusi</span></td>
  							</tr>
  							<tr>
  								<th> Terbitan </th>
  								<td><span class="badge badge-success">2001</span></td>
  							</tr>
  							<tr>
  								<th> Pengarang </th>
  								<td><span class="badge badge-success">Achmad</span></td>
  							</tr>
  							<tr>
  								<th> Penerbit </th>
  								<td><span class="badge badge-success">Anak Anak Reveolusi</span></td>
  							</tr>

  						</table>
  						<div class=" product-properties">

  							<span class="product-color">

  								<ul class="ul-color">
  									<li><a href="#" class="orange active"></a></li>
  									<li><a href="#" class="green"></a></li>
  									<li><a href="#" class="yellow"></a></li>
  								</ul>
  							</span>

  						</div>
  					</div>
  				</div>
  			</div>
  			<div class="col-md-4 ">
  				<div class="card satu mb-3">
  					<div class="card-head">
  						<img src="<?= base_url('assets/') ?>img/logo.png" alt="logo" class="card-logo">
  						<img src="<?= base_url('assets/') ?>img/gadjet.png" alt="Shoe" class="product-img mr-4" width="200px">

  						<span class="back-text">

  						</span>
  					</div>
  					<div class="card-body">
  						<table class="table table-borderless">
  							<!-- table table-borderless kegunaannya biar tabel gak memiliki border -->
  							<tr>
  								<th> Nama Buku </th>
  								<td><span class="badge badge-success">Anak Anak Reveolusi</span></td>
  							</tr>
  							<tr>
  								<th> Terbitan </th>
  								<td><span class="badge badge-success">2001</span></td>
  							</tr>
  							<tr>
  								<th> Pengarang </th>
  								<td><span class="badge badge-success">Achmad</span></td>
  							</tr>
  							<tr>
  								<th> Penerbit </th>
  								<td><span class="badge badge-success">Anak Anak Reveolusi</span></td>
  							</tr>

  						</table>
  						<div class=" product-properties">

  							<span class="product-color">

  								<ul class="ul-color">
  									<li><a href="#" class="orange active"></a></li>
  									<li><a href="#" class="green"></a></li>
  									<li><a href="#" class="yellow"></a></li>
  								</ul>
  							</span>

  						</div>
  					</div>
  				</div>
  			</div>


  		</div>

  	</div>
  	<!-- tutup gallery -->
  </div>
  </div>
