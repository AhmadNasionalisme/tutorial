<footer>
	<div class="copyright text-center text-white font-weight-bold bg-primary p-3">
		<p>&copy;copyright2019 | built with <i class="glyphicon glyphicon-fire"></i> by.<a href="https://www.facebook.com/ahmad.rendaisuke">Achmad mustofa</a>.</p>

	</div>
</footer>
<!-- tutup footer -->

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script>
	$(function() {
		$('.nav a').filter(function() {
			return this.href == location.href
		}).parent().addClass('active').siblings().removeClass('active');

		$('.nav a').click(function() {
			$(this).parent().addClass('active').siblings().removeClass('active')
		});
	});
</script>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
