<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">

	<title>Login Form</title>
</head>

<body>

	<div class="content mt-4">
		<div class="container wd-xl-40p wd-lg-40p ws-md-70p wd-sm-100p wd-xs-100p">
			<div class="row justify-content-center">

				<div class="card">
					<div class="card-header">
						<div class="logo-container tx-center mb-2">
							<img alt="Account, avatar, login, member, profile, user icon" class="n3VNCb" src="https://cdn2.iconfinder.com/data/icons/audio-16/96/user_avatar_profile_login_button_account_member-512.png" data-noaft="1" jsname="HiaYvf" jsaction="load:XAeZkd;" style="width: 124px; ">
						</div>
						<div class="tx-center tx-medium tx-xs-16 tx-sm-22 tx-md-24">Login</div>
					</div>
					<div class="card-body">



						<form action="">
							<div class="form-group">
								<label for="exampleInputEmail1">Email address</label>
								<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

							</div>
							<div class="form-group">
								<label for="password">password</label>
								<input type="password" class="form-control" id="password" aria-describedby="emailHelp">

							</div>
							<a href="">Lupa Password?</a>
							<div class="form-group mt-3">
								<button id="btn-login" type="submit" class="btn btn-primary btn-block mt-2">Masuk</button>

							</div>
						</form>
					</div>

				</div>
			</div>
		</div>
	</div>


	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
</body>

</html>
