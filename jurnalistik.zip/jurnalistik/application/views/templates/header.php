<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous" />


	<title><?= $title; ?></title>
	<link href="https://fonts.googleapis.com/css?family=Montserrat:100,600&display=swap" rel="stylesheet" />
	<!-- font ini dari www.fonts google.com -->
	<link rel="stylesheet" href="<?= base_url('assets/'); ?>fontawesome/css/all.min.css" />
	<link rel="stylesheet" href="<?= base_url('assets/'); ?>style.css">

</head>

<body>
	<!-- cards -->

	<div class="card " style="background-color: #050A27;">
		<!-- ubah warna -->
		<div class="card-body pl-5 pb-5">
			<!-- pl supaya agak geser ke kanan -->
			<!-- nav -->
			<nav class="navbar navbar-expand-lg p-3">
				<div class="container">
					<a class="navbar-brand wow bounceInDown" href="#">
						<h3>Achmadku</h3>
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
						<div class="navbar-nav ml-auto">

							<a class="nav-item nav-link  wow bounceInDown" href="<?= base_url('jurnal'); ?>" data-wow-duration="0.5s" data-wow-delay="0.2s">Home</a>
							<a class="nav-item nav-link  active wow bounceInDown" href="<?= base_url('jurnal/gallery'); ?>" data-wow-duration="1s" data-wow-delay="0.2s">Gallery</a>
							<a class="nav-item nav-link wow bounceInDown" href="#" data-wow-duration="1.5s" data-wow-delay="0.2s">Contact</a>
							<a class="nav-item nav-link wow bounceInDown" href="#" data-wow-duration="2s" data-wow-delay="0.2s">Berita</a>
							<a class="nav-item nav-link enjoy-now btn btn-primary wow bounceInDown" href="" data-wow-duration="2.5s" data-wow-delay="0.2s">Dashboard</a>
						</div>
					</div>
				</div>
			</nav>
			<!-- akhir nav -->
