<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jurnal extends CI_Controller
{
	public function index()
	{
		$data['title'] = 'Forum Jurnalistik';
		$this->load->view("templates/header", $data);
		$this->load->view("templates/jurnalis", $data);
		$this->load->view("templates/footer", $data);
	}
	public function gallery()
	{
		$data['title'] = 'Galery Buku';
		$this->load->view("templates/header", $data);
		$this->load->view("templates/gallery-buku", $data);
		$this->load->view("templates/footer", $data);
	}
	public function Login()
	{
		$data['title'] = 'Login';
		$this->load->view("templates/login", $data);
	}
}
